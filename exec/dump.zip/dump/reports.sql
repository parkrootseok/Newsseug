insert into newsseug.reports (report_id, article_id, type, activation_status, created_at, updated_at)
values  (1, 27, 'DISLIKE', 'ACTIVE', '2024-10-11 03:20:36', '2024-10-11 03:20:36'),
        (2, 77, 'SPAM', 'ACTIVE', '2024-10-11 08:40:41', '2024-10-11 08:40:41'),
        (3, 41, 'HATE_SPEECH_OR_SYMBOLS', 'ACTIVE', '2024-10-11 08:46:56', '2024-10-11 08:46:56');